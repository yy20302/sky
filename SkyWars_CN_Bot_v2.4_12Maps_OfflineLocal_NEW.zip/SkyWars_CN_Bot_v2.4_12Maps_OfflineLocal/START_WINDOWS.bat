@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
where java >nul 2>nul
if errorlevel 1 (
  echo Java was not found. Install 64-bit Java 8 or 11 and add java to PATH.
  pause
  exit /b 1
)
if not exist "paper-1.8.8-445.jar" (
  echo Missing paper-1.8.8-445.jar.
  echo Put this script in the server folder next to the jar and eula.txt.
  pause
  exit /b 1
)
if not exist "log4j2-paper-protected.xml" (
  echo Missing log4j2-paper-protected.xml. Do not start without this file.
  echo Copy it from the original server package into this folder.
  pause
  exit /b 1
)
echo Read https://www.minecraft.net/eula before setting eula=true in eula.txt.
echo The server checks the EULA. This script does not accept it for you.
echo Starting SkyWars. The first start needs Internet to download server files.
echo Keep this window open while playing. To stop, type stop and press Enter.
java -Dfile.encoding=UTF-8 -Dsun.stdout.encoding=UTF-8 -Dsun.stderr.encoding=UTF-8 -Dlog4j.configurationFile=log4j2-paper-protected.xml -Xms256M -Xmx1024M -XX:MaxDirectMemorySize=128M -jar paper-1.8.8-445.jar nogui
set "server_exit=%errorlevel%"
echo.
echo Server stopped. If startup failed, check the messages above and logs/latest.log.
echo If asked to accept the EULA, check and save eula.txt in this folder.
pause
exit /b %server_exit%
