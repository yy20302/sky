#!/bin/sh
set -eu
cd "$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
if ! command -v java >/dev/null 2>&1; then
  echo '未找到 Java：请安装 64 位 Java 8 或 11，并把 java 加入 PATH。' >&2
  exit 1
fi
if ! grep -iq '^eula=true$' eula.txt 2>/dev/null; then
  echo '请先阅读 https://www.minecraft.net/eula；同意后把 eula.txt 中 eula=false 改为 eula=true。' >&2
  exit 1
fi
echo '正在启动空岛战争服务器；首次启动需联网下载官方服务端。停止时输入 stop。'
exec java -Dfile.encoding=UTF-8 -Dlog4j.configurationFile=log4j2-paper-protected.xml -Xms256M -Xmx1024M -XX:MaxDirectMemorySize=128M -jar paper-1.8.8-445.jar nogui
